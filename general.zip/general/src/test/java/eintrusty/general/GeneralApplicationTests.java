package eintrusty.general;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeneralApplicationTests {

	@Test
	void contextLoads() {
	}

}
