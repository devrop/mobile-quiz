package eintrusty.mobile.quiz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobileQuizApplication {

	public static void main(String[] args) {
		SpringApplication.run(MobileQuizApplication.class, args);
	}

}
