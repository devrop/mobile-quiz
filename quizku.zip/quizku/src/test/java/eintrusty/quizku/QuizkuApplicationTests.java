package eintrusty.quizku;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizkuApplicationTests {

	@Test
	void contextLoads() {
	}

}
