package eintrusty.quizku;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuizkuApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuizkuApplication.class, args);
	}

}
